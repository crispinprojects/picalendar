#!/bin/bash
# Under the terms of the GNU General Public License enclosed. See license file.
echo "Pi Calendar system installer"
echo "This installer script assumes that the GTK4, SQLITE3 and ALSA base libraries are already installed."
echo "It also assumes that you are a member of the sudo group."
echo "See webpage for more information."
read -p "Do you want to proceed? (yes/no) " yn

case $yn in 
	yes ) echo ok, install will proceed;;
	no ) echo exiting installation;
		exit;;
	* ) echo invalid response;
		exit 1;;
esac

DIR=/usr/bin/picalendar
if [ ! -d "$DIR" ]; then
echo "making install directory"
sudo mkdir /usr/bin/picalendar
fi

echo "copying Pi Calendar to install directory"
sudo cp picalendar /usr/bin/picalendar
sudo cp calendar.png /usr/bin/picalendar
echo "creating Pi Calendar desktop file"
# adding desktop file
cat > ./temp << "EOF"
[Desktop Entry]
Version=0.2.1
Type=Application
Name=Pi Calendar
Comment=Calendar for Raspberry Pi OS
Comment[de]=Kalender für Raspberry Pi OS
Commnet[fr]=Calendrier pour le système d'exploitation Raspberry Pi
Exec=/usr/bin/picalendar/./picalendar
Icon=/usr/bin/picalendar/calendar.png
Terminal=false
Categories=Office;
MineType=text/calendar;
StartupNotify=true
EOF
sudo cp ./temp /usr/share/applications/picalendar.desktop;
rm ./temp




