#!/bin/bash
# Under the terms of the GNU General Public License enclosed. See license file.
# Pi Calendar bash script uninstaller

echo "Uninstall Pi Calendar"
echo "This will remove Pi Calendar from your system"
read -p "Do you want to proceed? (yes/no) " yn

case $yn in 
	yes ) echo ok, uninstall will proceed;;
	no ) echo exiting...;
		exit;;
	* ) echo invalid response;
		exit 1;;
esac

DIR=/usr/bin/picalendar
if [ -d "$DIR" ]; then
  echo "$DIR exists"
    echo "removing Pi Calendar"    
    sudo rm -r /usr/bin/picalendar
    sudo rm /usr/share/applications/picalendar.desktop
    sudo rm /etc/xdg/autostart/picalendar.desktop    
else
	echo "Pi Calendar directory does not exist, exiting"
	exit
fi





